import './Steam.css';
const Steam = () => {
  return (
    <div id='container'>
      <div class='steam' id='steam1'>
        {' '}
      </div>
      <div class='steam' id='steam2'>
        {' '}
      </div>
      <div class='steam' id='steam3'>
        {' '}
      </div>
      <div class='steam' id='steam4'>
        {' '}
      </div>
    </div>
  );
};

export default Steam;
